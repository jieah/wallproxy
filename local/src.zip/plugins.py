from __future__ import with_statement
def paas():
    print 'Initializing PAAS for proxy based on cloud service.'
    class _3(object):
        (set_hosts, Forward,) = config.import_from('util')
        (HeaderDict, Proxy, URLInfo, unparse_netloc, del_bad_hosts,) = config.import_from(utils)
        v = (set_hosts, Forward, HeaderDict, Proxy, URLInfo, unparse_netloc, del_bad_hosts)
    (_5, ____________, ________, __________, _2, _______________, _6,) = _3.v
    import re as _8
    import zlib as _4
    import socket as _0
    import struct as ____
    import time as ___________
    import random as _1
    import threading as _______
    from binascii import a2b_hex as _________, b2a_hex as ___________________
    from base64 import b64encode as __________________
    try:
        import ssl as ________________
    except ImportError:
        ________________ = None
    class _________________(Exception):
        def __init__(__, ____, __________):
            __.code = ____
            __.msg = __________

        def __str__(__________):
            return ('HTTP Error %s: %s' % (__________.code, __________.msg))

    _9 = _8.compile('(\\d+)?-(\\d+)?')
    ______________ = _8.compile('bytes\\s+(\\d+)-(\\d+)/(\\d+)')
    def _____________(_________, _____):
        __ = _________.get('Range', '')
        ________ = _9.search(__)
        if ________:
            ________ = ________.groups()
            if ________[0]:
                _____ -= 1
                if ________[1]:
                    ________ = (2, int(________[0]), int(________[1]))
                    if ((________[2] - ________[1]) > _____):
                        __ = ('bytes=%d-%d' % (________[1], (________[1] + _____)))
                else:
                    ________ = (0, int(________[0]))
                    __ = ('bytes=%d-%d' % (________[1], (________[1] + _____)))
            elif ________[1]:
                ________ = (1, int(________[1]))
                if (________[1] > _____):
                    __ = 'bytes=-1024'
            else:
                ________ = (None,)
                __ = ('bytes=0-%d' % (_____ - 1))
        else:
            ________ = (None,)
            __ = ('bytes=0-%d' % (_____ - 1))
        return (________, __)

    _7 = _8.compile(', ([^ =]+(?:=|$))')
    def ____________________(__):
        _____ = __.get('Set-Cookie')
        if _____:
            __['Set-Cookie'] = _7.sub('\\r\\nSet-Cookie: \\1', _____)
        return __

    def __(**__):
        _________ = _____
        ______________ = __.get('appids', '')
        _________.appids = ______________ = (______________.split() if isinstance(______________, str) else list(______________))
        if not ______________:
            raise ValueError('no appids specified')
        _______ = __.get('scheme', 'http').lower()
        if (_______ not in ('http', 'https')):
            raise ValueError(('invalid scheme: ' + _______))
        _________.url = _2(('%s://%s.appspot.com%s?' % (_______, _________.appids[0], __.get('path', '/fetch.py'))))
        _________.password = __.get('password', '')
        ______________ = __.get('proxy', 'default')
        _________.proxy = (config.global_proxy if (______________ == 'default') else __________(______________))
        ______________ = __.get('hosts')
        if ______________:
            ______________ = (______________.split() if isinstance(______________, str) else list(______________))
        if not ______________:
            ______________ = 'eJxdztsNgDAMQ9GNIvIoSXZjeApSqc3nUVT3ZojakFTR47wSNEhB8qXhorXg+kMjckGtQM9efDKf91Km4W+N4M1CldNIYMu+qSVoTm7MsG5E4KPd8apInNUUMo4betRQjg=='.decode('base64').decode('zlib').split('|')
        _5('.appspot.com', ______________, 0)
        if _________.proxy.value:
            _________.hosts = ______________
            _________.proxy = _________.proxy.new_hosts((______________[0], _________.url.port))
        _________.headers = ________(__.get('headers', 'Content-Type: application/octet-stream'))
        ______________ = __.get('max_threads', 0)
        _________.max_threads = min(10, (10 if (______________ <= 0) else ______________), len(_________.appids))
        _________.bufsize = __.get('bufsize', 8192)
        _________.maxsize = __.get('maxsize', 1000000)
        _________.waitsize = __.get('waitsize', 500000)
        assert (_________.bufsize <= _________.waitsize <= _________.maxsize)
        _________.local_times = __.get('local_times', 3)
        _________.server_times = __.get('server_times')
        _________.fetch_mode = __.get('fetch_mode', 0)
        _________.fetch_args = __.get('fetch_args', {})
        print ('  Init GAE with appids: %s' % '|'.join(_________.appids))
        print ('  max_threads when range fetch: %d' % _________.max_threads)
        ______________ = __.get('listen')
        if ______________:
            def ___(_______):
                if _______.proxy_type.endswith('http'):
                    return _________

            ______________ = data['GAE_server'] = utils.start_new_server(______________, ___)
            print ('  GAE listen on: %s' % _______________(______________.server_address[:2]))
        return _________

    class _12(object):
        skip_headers = frozenset(['Proxy-Connection', 'Content-Length', 'Host', 'Vary', 'Via',
         'X-Forwarded-For', 'X-ProxyUser-IP'])
        def build_params(_________, __________, _______):
            ___ = __________.command
            ___________ = __________.headers
            if (___ == 'GET'):
                (__________.rangeinfo, __,) = _____________(___________, _________.maxsize)
                if (_______ or (__________.rangeinfo[0] == 0)):
                    ___________['Range'] = __
            else:
                (__________.rangeinfo, __,) = ((None,), '')
            ______ = _________.skip_headers
            ___________.data = dict((_______ for _______ in ___________.iteritems() if (_______[0] not in ______)))
            ______________ = {'url': __________.url,
             'method': ___,
             'headers': ___________,
             'payload': __________.read_body()}
            if __:
                ______________['range'] = __
            if _________.password:
                ______________['password'] = _________.password
            if _________.server_times:
                ______________['fetchmax'] = _________.server_times
            return (______________,
             dict(_________.fetch_args, proxy_auth=__________.userid))

        def fetch(_8, (___________, _______________,), server=None):
            ___________ = _4.compress('&'.join([('%s=%s' % (_______, ___________________(str(_7)))) for (_______, _7,) in ___________.iteritems()]), 9)
            _3 = []
            _5 = (server or _8.url)
            ___ = _8.proxy.get_opener(_5.scheme, _______________)
            _11 = _2 = 0
            ______ = _8.local_times
            __________ = len(_8.appids)
            while ((_11 < ______) and (_2 < __________)):
                _9 = 0
                try:
                    _12 = ___.open(_5, ___________, 'POST', _8.headers, 0)
                    if (_12.status != 200):
                        _12.close()
                        raise _________________(_12.status, _12.reason)
                except Exception, ________________:
                    ___.close()
                    if isinstance(________________, _________________):
                        _3.append(str(________________))
                        if (________________.code == 503):
                            _11 -= 1
                            if server:
                                _5 = _8.url
                                server.__init__(_5)
                                server = None
                            else:
                                _2 += 1
                                _8.appids.append(_8.appids.pop(0))
                                _9 |= 1
                                _5.hostname = ('%s.appspot.com' % _8.appids[0])
                                print ('GAE: switch appid to %s' % _8.appids[0])
                        elif (________________.code == 404):
                            if _8.proxy.value:
                                _8.hosts.append(_8.hosts.pop(0))
                                _9 |= 2
                                print ('GAE: switch host to %s' % _8.hosts[0])
                            else:
                                _6()
                        elif (________________.code == 502):
                            if (_5.scheme != 'https'):
                                _11 -= 1
                                _5.scheme = 'https'
                                _5.port = 443
                                _9 |= 3
                                print 'GAE: switch scheme to https'
                    elif isinstance(________________, _0.error):
                        _______ = ________________.args[0]
                        if ((_5.scheme != 'https') and (_______ in (10054, 54, 20054))):
                            _11 -= 1
                            _5.scheme = 'https'
                            _5.port = 443
                            _9 |= 3
                            print 'GAE: switch scheme to https'
                        elif _8.proxy.value:
                            _3.append(('Connect other proxy failed: %s' % ________________))
                            _8.hosts.append(_8.hosts.pop(0))
                            _9 |= 2
                            print ('GAE: switch host to %s' % _8.hosts[0])
                        else:
                            _3.append(('Connect fetchserver failed: %s' % ________________))
                            if (_6() and (_______ in (10054, 54, 20054, 10047))):
                                _11 -= 1
                    else:
                        _3.append(('Connect fetchserver failed: %s' % ________________))
                    if (_9 & 1):
                        _5.rebuild()
                    if (_9 & 2):
                        if _8.proxy.value:
                            _8.proxy = _8.proxy.new_hosts((_8.hosts[0], _5.port))
                        ___ = _8.proxy.get_opener(_5.scheme, _______________)
                else:
                    try:
                        _9 = _12.read(1)
                        if (_9 == '0'):
                            (_13, ____________, _____________,) = ____.unpack('>3I', _12.read(12))
                            __________________ = ________([(_______, _________(_7)) for (_______, _10, _7,) in (___.partition('=') for ___ in _12.read(____________).split('&'))])
                            if ((_8.fetch_mode == 1) or ((_13 == 206) and (_8.fetch_mode == 2))):
                                _12 = _12.read()
                        elif (_9 == '1'):
                            _1 = _4.decompress(_12.read())
                            _12.close()
                            (_13, ____________, _____________,) = ____.unpack('>3I', _1[:12])
                            __________________ = ________([(_______, _________(_7)) for (_______, _10, _7,) in (_____.partition('=') for _____ in _1[12:(12 + ____________)].split('&'))])
                            _12 = _1[(12 + ____________):((12 + ____________) + _____________)]
                        else:
                            raise ValueError(('Data format not match(%s)' % _5))
                        __________________.setdefault('Content-Length', str(_____________))
                        return (0, (_13, __________________, _12))
                    except Exception, ________________:
                        _3.append(str(________________))
                _11 += 1
            return ((-1), _3)

        def write_content(________, _____, ___, first=False):
            __ = _____.socket.sendall
            if isinstance(___, str):
                __(___)
            else:
                _______ = ________.bufsize
                ______ = ___.read((________.waitsize if first else _______))
                while ______:
                    __(______)
                    ______ = ___.read(_______)
                ___.close()

        def need_range_fetch(_________________, _____________, __, ____):
            _______ = ______________.search(__.get('Content-Range', ''))
            if not _______:
                return
            _______ = map(int, _______.groups())
            _______________ = _____________.rangeinfo
            _________ = _______________[0]
            if (_________ is None):
                ______ = 0
                __________ = _______[2]
                ____________ = 200
                del __['Content-Range']
            else:
                if (_________ == 0):
                    ______ = _______________[1]
                    __________ = _______[2]
                elif (_________ == 1):
                    ______ = (_______[2] - _______________[1])
                    __________ = _______[2]
                else:
                    ______ = _______________[1]
                    __________ = (_______________[2] + 1)
                ____________ = 206
                __['Content-Range'] = ('bytes %d-%d/%d' % (______, (__________ - 1), _______[2]))
            __['Content-Length'] = str((__________ - ______))
            _____________.start_response(____________, ____________________(__))
            if (______ == _______[0]):
                return [______, __________, (_______[1] + 1), ____]
            return [______, __________, ______, None]

        def range_fetch(__________, _____________, _______, ________):
            _______[0].pop('range', None)
            ____ = (________[1] - ________[0])
            if ((__________.max_threads > 1) and ((________[1] - ________[2]) > __________.maxsize)):
                __ = __________._thread_range
            else:
                __ = __________._single_range
            _____ = ___________.time()
            if __(_____________, _______, ________):
                _____ = ((____ / 1000.0) / ((___________.time() - _____) or 0.0001))
                print ('>>>>>>>>>> Range Fetch ended (all @ %sKB/s)' % _____)
            else:
                _____________.close_connection = True
                print '>>>>>>>>>> Range Fetch failed'

        def _single_range(___, _______, ________, ____________________):
            (___________________, __, _____________, ______,) = ____________________
            del ____________________[:]
            __ -= 1
            _________________ = ___.maxsize
            ________________ = 0
            _________ = ________[0]['headers']
            print ('>>>>>>>>>> Range Fetch started%s: bytes=%d-%d, step=%d' % (_______.proxy_host, ___________________, __, _________________))
            if ______:
                ___.write_content(_______, ______, True)
            while (_____________ <= __):
                if (________________ > 16):
                    return False
                _________['Range'] = ('bytes=%d-%d' % (_____________, min((_____________ + _________________), __)))
                (__________________, ____________________,) = ___.fetch(________)
                if (__________________ != (-1)):
                    (____, __________, ______,) = ____________________
                    ____________ = ______________.search(__________.get('Content-Range', ''))
                if ((__________________ == (-1)) or (____ >= 400)):
                    ________________ += 1
                    _______________ = _1.randint((2 * ________________), (2 * (________________ + 1)))
                    ___________.sleep(_______________)
                elif ('Location' in __________):
                    ________________ += 1
                    ________[0]['url'] = __________['Location']
                elif not ____________:
                    ________________ += 1
                else:
                    print ('>>>>>>>>>> %s' % __________['Content-Range'])
                    ________________ = 0
                    ___.write_content(_______, ______)
                    _____________ = (int(____________.group(2)) + 1)
            return True

        def _thread_range(__________, _____, ____________, __):
            (___, _________, __, _______________,) = __________._start_thread_range(_____, ____________, __)
            ____ = 0
            while (____ < _________):
                if __[1]:
                    print ('>>>>>>>>>> failed@%d bytes=%d-%d' % tuple(__[1][2:5]))
                    return False
                _______ = ___[____]
                if not isinstance(_______[0], int):
                    if _______[0]:
                        _______________(_______[0], _______)
                    ____ += 1
                    continue
                ___________.sleep(0.001)
            return True

        def _start_thread_range(____, ___, ____________________, _0):
            (______________, _________________, ______, ________,) = _0
            del _0[:]
            ___________________ = ____.maxsize
            _____________ = (___________________ - 1)
            __ = []
            ________________ = 1
            while (______ < _________________):
                __.append([0, set(), ________________, ______, (______ + _____________)])
                ______ += ___________________
                ________________ += 1
            _________________ -= 1
            __[(-1)][(-1)] = _________________
            _________ = len(__)
            _____ = min(_________, ____.max_threads)
            __________ = _______.Lock()
            _______________ = _______.Lock()
            _0 = [1, None, _____]
            def ____________(________________, _________):
                try:
                    ______________ = None
                    if ((_0[0] != _________[2]) or not _______________.acquire(0)):
                        ______________ = []
                        ___________ = ________________.read(8192)
                        while ___________:
                            ______________.append(___________)
                            if ((_0[0] == _________[2]) and _______________.acquire(0)):
                                break
                            ___________ = ________________.read(8192)
                        else:
                            ________________.close()
                            __________.acquire()
                            _________[0] = ''.join(______________)
                            __________.release()
                            return
                    try:
                        _0[0] += 1
                        print ('>>>>>>>>>> block=%d bytes=%d-%d' % tuple(_________[2:5]))
                        if ______________:
                            ___.socket.sendall(''.join(______________))
                        ____.write_content(___, ________________)
                        _________[0] = None
                    finally:
                        _______________.release()
                except:
                    __________.acquire()
                    del __[:]
                    _0[1] = _________
                    __________.release()

            ___________ = ____.appids[1:]
            _1.shuffle(___________)
            ___________.append(____.appids[0])
            ___________ = ___________[:_____]
            print ('>>>>>>>>>> Range Fetch started: threads=%d blocks=%d bytes=%d-%d appids=%s' % (_____, _________, ______________, _________________,
             '|'.join(___________)))
            ______________ = (0, (), 0, ______________, (__[0][3] - 1))
            try:
                with _______________:
                    for ________________ in xrange(_____):
                        _____________ = _______.Thread(target=____._range_thread, args=(___________[________________], ____________________, __,
                         __________, _0, ____________))
                        _____________.setDaemon(True)
                        _____________.start()
                    if ________:
                        print ('>>>>>>>>>> block=%d bytes=%d-%d' % ______________[2:5])
                        ____.write_content(___, ________, True)
            except:
                __________.acquire()
                del __[:]
                _0[1] = ______________
                __________.release()
            return (__, _________, _0, ____________)

        def _range_thread(__, ____________________, _____, __________, _________, __________________, ____________):
            ____________________ = _2(__.url, hostname=('%s.appspot.com' % ____________________))
            _______________ = _____[0].copy()
            _______________['headers'] = ______ = ________(_______________['headers'])
            _____ = (_______________, _____[1])
            _______________ = _______.current_thread()
            while 1:
                with _________:
                    try:
                        for _____________ in __________:
                            if (_____________[0] == 0):
                                ____ = _____________[1]
                                if (len(____) == __________________[2]):
                                    ____.clear()
                                if (_______________ not in ____):
                                    _____________[0] = 1
                                    break
                        else:
                            for _____________ in __________:
                                _____________[1].discard(_______________)
                            __________________[2] -= 1
                            raise StopIteration('No task for me')
                    except StopIteration:
                        break
                ______['Range'] = ('bytes=%d-%d' % (_____________[3], _____________[4]))
                while 1:
                    if not __________:
                        return
                    (___________, ______________,) = __.fetch(_____, ____________________)
                    if not __________:
                        return
                    if ((___________ != (-1)) and (______________[0] == 206)):
                        ______________ = ______________[2]
                        if isinstance(______________, str):
                            _________.acquire()
                            _____________[0] = ______________
                            _________.release()
                        else:
                            ____________(______________, _____________)
                        break
                    with _________:
                        if (_____________[0] >= 2):
                            ____.add(_______________)
                            _____________[0] = 0
                            break
                        _____________[0] += 1

        def __call__(_____, ___________, force_range=False):
            ___________.handler_name = 'GAE'
            _______ = _____.build_params(___________, force_range)
            (___, ______________,) = _____.fetch(_______)
            if (___ == (-1)):
                return ___________.send_error(502, str(______________))
            (_____________, ______, ________,) = ______________
            if ((_____________ == 206) and (___________.command == 'GET')):
                ______________ = _____.need_range_fetch(___________, ______, ________)
                if ______________:
                    del _____________
                    del ______
                    del ________
                    return _____.range_fetch(___________, _______, ______________)
            ___________.start_response(_____________, ____________________(______))
            _____.write_content(___________, ________)

    _____ = _12()
    def ___(**____________):
        ___ = _10()
        ___.url = _____ = _2(____________['url'])
        ___.password = ____________.get('password', '')
        ______ = ____________.get('proxy', 'default')
        ___.proxy = (config.global_proxy if (______ == 'default') else __________(______))
        ___.hosts = None
        ______ = ____________.get('hosts')
        if ______:
            ______ = (______.split() if isinstance(______, str) else list(______))
            if ___.proxy.value:
                if (len(______) > 1):
                    ___.hosts = ______
                ___.proxy = ___.proxy.new_hosts((______[0], _____.port))
            else:
                _5(_____.hostname, ______, 0)
        ___.headers = ________(____________.get('headers', 'Content-Type: application/octet-stream'))
        ___.fetch_args = ____________.get('fetch_args', {})
        print ('  Init PAAS with url: %s' % _____)
        ______ = ____________.get('listen')
        if ______:
            def ____(______):
                if ______.proxy_type.endswith('http'):
                    return ___

            ______ = data['PAAS_server'] = utils.start_new_server(______, ____)
            print ('  PAAS listen on: %s' % _______________(______.server_address[:2]))
        return ___

    class _10(object):
        def __call__(_____, ___________):
            ___________.handler_name = 'PAAS'
            ______________ = {'method': ___________.command,
             'url': ___________.url,
             'headers': ___________.headers}
            if _____.password:
                ______________['password'] = _____.password
            ______________ = '&'.join([('%s=%s' % (_______________, ___________________(str(___)))) for (_______________, ___,) in ______________.iteritems()])
            _____.headers['Cookie'] = __________________(_4.compress(______________, 9))
            _______ = _____.url
            try:
                _________________ = _____.proxy.get_opener(_______.scheme, dict(_____.fetch_args, proxy_auth=___________.userid)).open(_______, ___________.read_body(), 'POST', _____.headers, 0)
            except Exception, ________________:
                if _____.hosts:
                    _____.hosts.append(_____.hosts.pop(0))
                    print ('PAAS: switch host to %s' % _____.hosts[0])
                    _____.proxy = _____.proxy.new_hosts((_____.hosts[0], _______.port))
                    return ___________.send_error(502, ('Connect other proxy failed: %s' % ________________))
                return ___________.send_error(502, ('Connect fetchserver failed: %s' % ________________))
            ___________.start_response(_________________.status, ____________________(_________________.msg), _________________.reason)
            __ = ___________.socket.sendall
            _________ = _________________.read(8192)
            while _________:
                __(_________)
                _________ = _________________.read(8192)
            _________________.close()

    def ______(**______):
        ____ = _11()
        ________________ = _2(______['url'])
        ____.scheme = ________________.scheme
        ____.host = ________________.host
        ____.path = ________________.path
        _____________ = ______.get('password')
        ____.auth = (_____________ if (_____________ is None) else ('', _____________))
        _____________ = ______.get('proxy', 'default')
        ____.proxy = (config.global_proxy if (_____________ == 'default') else __________(_____________))
        if ((____.scheme == 'https') and ____.proxy.https_mode):
            ____.proxy = ____.proxy.https_mode
        ____.value = ____.hosts = None
        _____________ = ______.get('hosts')
        if _____________:
            _____________ = (_____________.split() if isinstance(_____________, str) else list(_____________))
            if ____.proxy.value:
                if (len(_____________) > 1):
                    ____.hosts = _____________
                ____.value = [_____________[0], ________________.port]
            else:
                _5(________________.hostname, _____________, 0)
        if not ____.value:
            ____.value = (________________.hostname, ________________.port)
        print ('  Init SOCKS5 with url: %s' % ________________)
        ____ = ____________(____)
        ____.handler_name = 'SOCKS5'
        _____________ = ______.get('listen')
        if _____________:
            _____________ = data['SOCKS5_server'] = utils.start_new_server(_____________, (lambda ___: ____))
            print ('  SOCKS5 listen on: %s' % _______________(_____________.server_address[:2]))
        return ____

    class _11(__________):
        __new__ = object.__new__
        def connect(__, ___, ________, cmd=1):
            try:
                ______ = __.proxy.connect(__.value, ________, 1)
            except Exception:
                if __.hosts:
                    __.hosts.append(__.hosts.pop(0))
                    print ('SOCKS5: switch host to %s' % __.hosts[0])
                    __.value[0] = __.hosts[0]
                raise 
            if (__.scheme == 'https'):
                try:
                    ______ = ________________.wrap_socket(______)
                except Exception, __________:
                    raise _0.error(__________)
            ______.sendall(('PUT %s HTTP/1.1\r\nHost: %s\r\nConnection: Keep-Alive\r\n\r\n' % (__.path, __.host)))
            ___ = __.handlers['socks5'](______, ______.makefile('rb', 0), __.auth, 0, ___, cmd)
            return __._proxysocket(______, ___)

    globals().update(GAE=__, PAAS=___, SOCKS5=______)
